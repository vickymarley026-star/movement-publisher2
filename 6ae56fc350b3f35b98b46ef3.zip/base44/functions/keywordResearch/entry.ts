const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req: Request): Promise<Response> {
  try {
    const body = await req.json();
    const topic = body?.topic?.trim();
    const genre = body?.genre?.trim();
    if (!topic) return Response.json({ error: 'Topic is required' }, { status: 400 });

    const base44 = createClientFromRequest(req);
    const prompt = `You are an Amazon KDP keyword research expert. A self-publishing author is writing a ${genre || 'fiction'} book about: "${topic}".
Suggest 15 high-potential Amazon Kindle search keywords or short phrases this author should target. For each keyword provide:
- keyword: the search term (typically 2-4 words)
- rationale: a brief reason it is a good fit (relevance, search volume signal, competition)
- competition: "low", "medium", or "high"
Return as JSON.`;

    const result = await db.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      add_context_from_internet: true,
      response_json_schema: {
        type: "object",
        properties: {
          keywords: {
            type: "array",
            items: {
              type: "object",
              properties: {
                keyword: { type: "string" },
                rationale: { type: "string" },
                competition: { type: "string" }
              }
            }
          }
        }
      }
    });

    return Response.json(result);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}